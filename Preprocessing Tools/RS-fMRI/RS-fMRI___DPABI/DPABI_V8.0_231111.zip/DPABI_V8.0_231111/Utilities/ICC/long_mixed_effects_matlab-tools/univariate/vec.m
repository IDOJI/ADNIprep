function h = vec(H)
% h = vec(H)
% 
% Vectorize matrix.
%
% H: Matrix
%
% $Revision: 1.1.1.1 $  $Date: 2011/11/10 01:25:52 $
% Original Author: Jorge Luis Bernal Rusiel 
% CVS Revision Info:
%    $Author: jbernal$
%    $Date: 2011/11/10 21:25:58 $
%    $Revision: 1.1 $
%
    
h = H(:);
   